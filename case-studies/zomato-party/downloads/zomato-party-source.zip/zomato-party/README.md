# Zomato Party

Independent product design concept by Joel Jojy. Unaffiliated with Zomato.

## Run locally
Use Node.js 22 or newer. In this folder run:

    npm ci
    npm run dev

Open the local URL printed by Vite. The initial screen is the host dashboard.
Use Party home to explore the welcome screen, set up a new party, or try the guest flow.

## Edit the design
App UI: src/Prototype.tsx
App styles: src/prototype.css
Party illustration and food images: public/assets/party/
Reusable mobile frame and controls: src/mobile/

## Scope
Frontend prototype with sample restaurants and orders. Approval and payment are separate.
Guest prices are hidden. Payment and tracking are simulated. No backend or production
Zomato integration. State is local and does not sync across devices or browser sessions.
The QR code opens the hosted invite but does not create a shared server session.

The UI screens archive and MP4 walkthrough are available separately on the case study.
No credentials, environment files or hosting account configuration are included here.
