Zomato Party — design exports

16 UI screens exported at native 1179 × 2556 resolution.
Party illustration included separately. Screens are PNG exports, not a Figma document.

Independent design exploration by Joel Jojy. Unaffiliated with Zomato.
Orders, payments and tracking are simulated. State is local to one browser session.
