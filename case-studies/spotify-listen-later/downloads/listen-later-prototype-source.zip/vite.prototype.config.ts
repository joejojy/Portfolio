import { mergeConfig } from 'vite';
import mobileConfig from './vite.config';
export default mergeConfig(mobileConfig,{base:'./',build:{rollupOptions:{input:{mobile:'index.html',desktop:'desktop.html'}}}});
