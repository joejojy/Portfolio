import React from 'react';
import { createRoot } from 'react-dom/client';
import { Experience } from './Prototype';
createRoot(document.getElementById('root')!).render(<React.StrictMode><Experience desktop/></React.StrictMode>);
