# Spotify Listen Later prototype

Independent concept by Joel Jojy. Mobile and desktop interactive frontends, based on the approved portfolio UI boards.

Run `npm ci`, then `npm run dev`. Open the mobile entry at `/` or desktop at `/desktop.html`. Build with `npm run build`; the static portfolio output is `dist/client`.

## Try the flow

1. Save Blue with the clock beside the library plus, or use Album options → Save to Listen Later.
2. Open Your Library → Listen Later (desktop also has a sidebar shortcut).
3. Filter, sort, resume, mark listened/unlistened or remove an item. Save and remove confirmations offer Undo.
4. Reset demo restores the sample collection. The iPhone / Pixel picker switches mobile preview devices.

## Scope

Playback is simulated, with progress and track controls. No Spotify authentication, audio, API, persistence or cross-device synchronization is connected. State resets on reload, and the mobile and desktop entries each start a separate session. Downloads, sharing, playlists, radio and Jam display explanatory feedback rather than performing external actions. Sample counts and progress are illustrative. No usability research or measured impact is claimed.

Album artwork and Spotify branding belong to their respective owners. The source includes the protected Product Design mobile preview runtime; see AGENTS.md for its editing boundary.
