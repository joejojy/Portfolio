import fs from 'node:fs';
import path from 'node:path';
import { createHash } from 'node:crypto';
const dir=path.resolve('dist/client/assets');
const renamed=[];
// Keep the protected runtime source intact while making its public assets
// relative to the portfolio's nested prototype URL in the published bundle.
for(const name of fs.readdirSync(dir).filter(n=>n.endsWith('.js'))){
 const file=path.join(dir,name);let text=fs.readFileSync(file,'utf8');
 text=text.replaceAll('"/assets/','"./assets/').replaceAll("'/assets/","'./assets/").replaceAll('`/assets/','`./assets/');
 const revised=name.replace(/\.js$/,`-${createHash('sha256').update(text).digest('hex').slice(0,8)}.js`);
 fs.writeFileSync(path.join(dir,revised),text);
 fs.unlinkSync(file);
 renamed.push([name,revised]);
}
for(const file of [...fs.readdirSync(dir).filter(n=>n.endsWith('.js')).map(n=>path.join(dir,n)),...['index.html','desktop.html'].map(n=>path.resolve('dist/client',n))]){
 let content=fs.readFileSync(file,'utf8');
 for(const [oldName,newName] of renamed)content=content.replaceAll(oldName,newName);
 fs.writeFileSync(file,content);
}
console.log('Prepared relative asset URLs for portfolio hosting.');
