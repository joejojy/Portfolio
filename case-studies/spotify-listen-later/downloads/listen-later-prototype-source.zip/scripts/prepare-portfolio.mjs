import fs from 'node:fs';
import path from 'node:path';
const dir=path.resolve('dist/client/assets');
// Keep the protected runtime source intact while making its public assets
// relative to the portfolio's nested prototype URL in the published bundle.
for(const name of fs.readdirSync(dir).filter(n=>n.endsWith('.js'))){
 const file=path.join(dir,name);let text=fs.readFileSync(file,'utf8');
 text=text.replaceAll('"/assets/','"./assets/').replaceAll("'/assets/","'./assets/");
 fs.writeFileSync(file,text);
}
console.log('Prepared relative asset URLs for portfolio hosting.');
